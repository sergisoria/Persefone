
-- --------------------------------------------------------

--
-- Estructura de la taula `productos`
--

CREATE TABLE `productos` (
  `IDProducto` int(50) NOT NULL,
  `Referencia` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `Nombre` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `Stock` int(11) NOT NULL,
  `Precio Unidad` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
