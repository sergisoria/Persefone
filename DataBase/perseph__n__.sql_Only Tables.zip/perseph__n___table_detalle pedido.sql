
-- --------------------------------------------------------

--
-- Estructura de la taula `detalle pedido`
--

CREATE TABLE `detalle pedido` (
  `IDDetallePedido` int(50) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Talla` decimal(10,0) NOT NULL,
  `Color` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
