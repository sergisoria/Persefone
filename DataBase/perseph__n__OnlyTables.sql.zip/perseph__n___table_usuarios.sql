
-- --------------------------------------------------------

--
-- Estructura de la taula `usuarios`
--

CREATE TABLE `usuarios` (
  `IDCuenta` int(50) NOT NULL,
  `Login` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `Password` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `Correo` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `Telefono` int(15) NOT NULL,
  `Nombre` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `Apellidos` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `Direccion` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `Rol` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
