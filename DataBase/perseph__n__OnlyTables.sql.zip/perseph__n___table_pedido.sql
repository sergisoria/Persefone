
-- --------------------------------------------------------

--
-- Estructura de la taula `pedido`
--

CREATE TABLE `pedido` (
  `IDPedido` int(50) NOT NULL,
  `Fecha Inicio` date NOT NULL,
  `Fecha Estimada` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
