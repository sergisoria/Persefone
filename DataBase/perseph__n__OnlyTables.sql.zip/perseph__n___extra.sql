
--
-- Índexs per a les taules bolcades
--

--
-- Índexs per a la taula `carrito`
--
ALTER TABLE `carrito`
  ADD PRIMARY KEY (`IDCarrito`);

--
-- Índexs per a la taula `detalle pedido`
--
ALTER TABLE `detalle pedido`
  ADD PRIMARY KEY (`IDDetallePedido`);

--
-- Índexs per a la taula `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`IDInventario`);

--
-- Índexs per a la taula `metodo pago`
--
ALTER TABLE `metodo pago`
  ADD PRIMARY KEY (`IDMetodoPago`);

--
-- Índexs per a la taula `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`IDPedido`);

--
-- Índexs per a la taula `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`IDProducto`);

--
-- Índexs per a la taula `promociones`
--
ALTER TABLE `promociones`
  ADD PRIMARY KEY (`IDPromocion`);

--
-- Índexs per a la taula `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`IDProveedor`);

--
-- Índexs per a la taula `tienda`
--
ALTER TABLE `tienda`
  ADD PRIMARY KEY (`IDTienda`);

--
-- Índexs per a la taula `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`IDCuenta`),
  ADD UNIQUE KEY `Login` (`Login`),
  ADD UNIQUE KEY `Correo` (`Correo`);

--
-- Índexs per a la taula `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`IDVenta`);
