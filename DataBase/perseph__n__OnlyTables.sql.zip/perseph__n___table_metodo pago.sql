
-- --------------------------------------------------------

--
-- Estructura de la taula `metodo pago`
--

CREATE TABLE `metodo pago` (
  `IDMetodoPago` int(50) NOT NULL,
  `TipoPago` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL,
  `Descripcion` varchar(50) CHARACTER SET utf32 COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
