
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `idInventario` int(11) NOT NULL,
  `PrecioUnidad` decimal(20,2) NOT NULL,
  `Stock` int(11) NOT NULL,
  `Tipo` varchar(30) NOT NULL,
  `Color` varchar(20) NOT NULL,
  `Talla` varchar(20) NOT NULL,
  `Genero` varchar(20) NOT NULL,
  `Imagen` longblob NOT NULL,
  `idTienda` int(11) NOT NULL,
  `idProveedor` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
