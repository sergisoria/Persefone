
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE `tipos` (
  `idTipos` int(11) NOT NULL,
  `NombreTipo` varchar(45) NOT NULL,
  `Web` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`idTipos`, `NombreTipo`, `Web`) VALUES
(1, 'Camisetas', NULL),
(2, 'Vestidos', NULL),
(3, 'Vaqueros', NULL),
(4, 'Chaquetas y Abrigos', NULL),
(5, 'Ropa de Deporte', NULL),
(6, 'Americanas', NULL),
(7, 'Zapatos', NULL),
(8, 'Gorras', NULL),
(9, 'Shorts', NULL),
(10, 'Bolsos', NULL);
