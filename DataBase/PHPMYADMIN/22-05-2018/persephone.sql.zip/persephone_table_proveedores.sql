
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `idProveedor` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  `Correo` varchar(50) NOT NULL,
  `Telefono` varchar(20) NOT NULL,
  `Webpage` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`idProveedor`, `Nombre`, `Direccion`, `Correo`, `Telefono`, `Webpage`) VALUES
(1, 'Gucci', 'Via Tornabuoni 73 50123 Florence, Italy.', 'clientservice-europe@it.gucci.com', '663717612', 'https://www.gucci.com/int/en/'),
(2, 'ASOS', '57056 Camden Town London, United Kingdom', 'asos@asos.com', '02073872032', 'http://www.asos.com/'),
(3, 'Levi Strauss', '1155 Battery Street San Francisco, California USA', 'newsmediarequests@levi.com', '415501777', 'http://www.levi.com'),
(4, 'Nike', 'Beaverton, Oregón USA', 'nike@nike.com', '913753366', 'https://www.nike.com/'),
(5, 'Pretty Little Thing', 'Manchester, United Kingdom', 'support@prettylittlething.com', '215131277', 'https://www.prettylittlething.com/'),
(6, 'Warehouse', 'London', 'support@warehouse.com', '+44 345 548 1000', 'http://www.warehouse-london.com/row/home');
