
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `idProveedor` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  `Correo` varchar(50) NOT NULL,
  `Telefono` varchar(20) NOT NULL,
  `Webpage` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`idProveedor`, `Nombre`, `Direccion`, `Correo`, `Telefono`, `Webpage`) VALUES
(1, 'Gucci', 'Via Tornabuoni 73 50123 Florence, Italy.', 'clientservice-europe@it.gucci.com', '663717612', 'https://www.gucci.com/int/en/'),
(2, 'ASOS', '57056 Camden Town London, United Kingdom', 'asos@asos.com', '02073872032', 'http://www.asos.com/'),
(3, 'Levi Strauss', '1155 Battery Street San Francisco, California USA', 'newsmediarequests@levi.com', '415501777', 'http://www.levi.com'),
(4, 'Nike', 'Beaverton, Oregón USA', 'nike@nike.com', '913753366', 'https://www.nike.com/'),
(5, 'Pretty Little Thing', 'Manchester, United Kingdom', 'support@prettylittlething.com', '215131277', 'https://www.prettylittlething.com/'),
(6, 'Warehouse', 'London, United Kingdom', 'support@warehouse.com', '+44 345 548 1000', 'http://www.warehouse-london.com/row/home'),
(7, 'Boohoo', 'Manchester, United Kingdom', 'customercare@mena.boohoo.com', '+9715126272', 'http://www.boohoo.com/'),
(8, 'Weekday', 'Manchester, United Kingdom', 'customerservice@weekday.com', '+442035147777', 'https://www.weekday.com/en_eur/index.html'),
(9, 'River Island', 'London, United Kingdom', 'customer.services@river-island.com', '+44 (0) 344 576 6444', 'https://eu.riverisland.com/'),
(10, 'Liquor N Poker', 'London, United Kingdom', ' info@liquornpoker.co.uk', '01384 262007', 'https://www.liquornpoker.co.uk/'),
(11, 'Armani Exchange', '111 8th Avenue 9th Floor , New York', 'customer.info@armaniexchange.com', '18666675856', 'https://www.armaniexchange.com/'),
(12, 'Brooklyn Denim Co', '338 Wythe Ave Brooklyn, New York', 'info@brooklyndenimco.com', '(718)782-2600', 'https://brooklyndenimco.com/'),
(13, 'Only & Sons', 'Dinamarca', 'customerservice@bestseller.com', '952055190', 'https://www.onlyandsons.com/es/es/home'),
(14, 'D-Struct', 'Manchester, United Kingdom', 'sales@stylewise-ltd.co.uk', '+4599423200', 'https://www.onlyandsons.com/es/es/home'),
(15, 'Kyoto London', 'Japan', 'help@kyotolondon.com', '+4599251215', 'https://www.kyotolondon.com/'),
(16, 'New Look', 'Weymouth, Dorset, United Kingdom', 'help@newlook.com', '0080009260926', 'http://www.newlook.com/row');
