
-- --------------------------------------------------------

--
-- Estructura de la taula `ventas`
--

CREATE TABLE `ventas` (
  `idVenta` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Valor Unidad` float NOT NULL,
  `idMetodo Pago` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
