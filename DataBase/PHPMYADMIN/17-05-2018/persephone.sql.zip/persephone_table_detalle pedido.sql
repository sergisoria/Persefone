
-- --------------------------------------------------------

--
-- Estructura de la taula `detalle pedido`
--

CREATE TABLE `detalle pedido` (
  `idDetalle Pedido` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Talla` decimal(10,0) NOT NULL,
  `Color` varchar(20) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `idPedido` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
