
-- --------------------------------------------------------

--
-- Estructura de la taula `productos`
--

CREATE TABLE `productos` (
  `idProducto` int(11) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Referencia` varchar(20) NOT NULL,
  `Stock` int(11) NOT NULL,
  `Precio Unidad` float NOT NULL,
  `Genero` varchar(20) NOT NULL,
  `idProveedor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Bolcament de dades per a la taula `productos`
--

INSERT INTO `productos` (`idProducto`, `Nombre`, `Referencia`, `Stock`, `Precio Unidad`, `Genero`, `idProveedor`) VALUES
(1, 'Camiseta Gucci', '03982718392', 30, 25, 'Masculino', 1);
