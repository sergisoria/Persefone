
-- --------------------------------------------------------

--
-- Estructura de la taula `metodo pago`
--

CREATE TABLE `metodo pago` (
  `idMetodo Pago` int(11) NOT NULL,
  `Tipo Pago` varchar(20) NOT NULL,
  `Descripcion` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Bolcament de dades per a la taula `metodo pago`
--

INSERT INTO `metodo pago` (`idMetodo Pago`, `Tipo Pago`, `Descripcion`) VALUES
(1, 'VISA', 'Tarjeta de Crédito de CaixaBank.\r\n3273 8193 7283 1726 \r\n03/21 ');
