
-- --------------------------------------------------------

--
-- Estructura de la taula `inventario`
--

CREATE TABLE IF NOT EXISTS `inventario` (
  `idInventario` int(11) NOT NULL,
  `Precio Unidad` float NOT NULL,
  `Stock` int(11) NOT NULL,
  `Imagen` blob NOT NULL,
  `idTienda` int(11) NOT NULL,
  `idProveedor` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL,
  PRIMARY KEY (`idInventario`),
  UNIQUE KEY `idInventario_UNIQUE` (`idInventario`),
  KEY `fk_Inventario_Tienda_idx` (`idTienda`),
  KEY `fk_Inventario_Proveedores1_idx` (`idProveedor`),
  KEY `fk_Inventario_Productos1_idx` (`idProducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
