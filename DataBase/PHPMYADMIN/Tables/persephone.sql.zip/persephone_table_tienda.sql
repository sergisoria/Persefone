
-- --------------------------------------------------------

--
-- Estructura de la taula `tienda`
--

CREATE TABLE IF NOT EXISTS `tienda` (
  `idTienda` int(11) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Direccion` varchar(20) NOT NULL,
  `Telefono` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idTienda`),
  UNIQUE KEY `idTienda_UNIQUE` (`idTienda`),
  KEY `fk_Tienda_Usuarios1_idx` (`idUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
