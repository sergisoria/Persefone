
-- --------------------------------------------------------

--
-- Estructura de la taula `promociones`
--

CREATE TABLE IF NOT EXISTS `promociones` (
  `idPromocion` int(11) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Fecha Inicio` date NOT NULL,
  `Fecha Final` date NOT NULL,
  `Descripcion` varchar(20) NOT NULL,
  `Descuento` int(11) NOT NULL,
  PRIMARY KEY (`idPromocion`),
  UNIQUE KEY `idPromocion_UNIQUE` (`idPromocion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
