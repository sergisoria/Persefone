
-- --------------------------------------------------------

--
-- Estructura de la taula `ventas`
--

CREATE TABLE IF NOT EXISTS `ventas` (
  `idVenta` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Valor Unidad` float NOT NULL,
  `idMetodo Pago` int(11) NOT NULL,
  PRIMARY KEY (`idVenta`),
  UNIQUE KEY `idVenta_UNIQUE` (`idVenta`),
  KEY `fk_Ventas_Metodo Pago1_idx` (`idMetodo Pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
