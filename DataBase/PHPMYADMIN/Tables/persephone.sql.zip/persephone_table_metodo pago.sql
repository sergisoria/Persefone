
-- --------------------------------------------------------

--
-- Estructura de la taula `metodo pago`
--

CREATE TABLE IF NOT EXISTS `metodo pago` (
  `idMetodo Pago` int(11) NOT NULL,
  `Tipo Pago` varchar(20) NOT NULL,
  `Descripcion` varchar(20) NOT NULL,
  PRIMARY KEY (`idMetodo Pago`),
  UNIQUE KEY `idMetodo Pago_UNIQUE` (`idMetodo Pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
