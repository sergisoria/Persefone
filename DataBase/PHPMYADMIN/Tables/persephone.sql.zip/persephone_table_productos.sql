
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `idProducto` int(11) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Referencia` varchar(20) NOT NULL,
  `Stock` int(11) NOT NULL,
  `PrecioUnidad` decimal(10,0) NOT NULL,
  `Genero` varchar(20) NOT NULL,
  `Imagen` longblob NOT NULL,
  `idProveedor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
