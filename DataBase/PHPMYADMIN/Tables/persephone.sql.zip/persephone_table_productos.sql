
-- --------------------------------------------------------

--
-- Estructura de la taula `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `idProducto` int(11) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Referencia` varchar(20) NOT NULL,
  `Stock` int(11) NOT NULL,
  `Precio Unidad` float NOT NULL,
  `Genero` varchar(20) NOT NULL,
  `idProveedor` int(11) NOT NULL,
  PRIMARY KEY (`idProducto`),
  UNIQUE KEY `idProducto_UNIQUE` (`idProducto`),
  KEY `fk_Productos_Proveedores1_idx` (`idProveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
