
-- --------------------------------------------------------

--
-- Estructura de la taula `detalle pedido`
--

CREATE TABLE IF NOT EXISTS `detalle pedido` (
  `idDetalle Pedido` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Talla` decimal(10,0) NOT NULL,
  `Color` varchar(20) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `idPedido` int(11) NOT NULL,
  PRIMARY KEY (`idDetalle Pedido`),
  UNIQUE KEY `idDetalle Pedido_UNIQUE` (`idDetalle Pedido`),
  KEY `fk_Detalle Pedido_Productos1_idx` (`idProducto`),
  KEY `fk_Detalle Pedido_Pedido1_idx` (`idPedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
