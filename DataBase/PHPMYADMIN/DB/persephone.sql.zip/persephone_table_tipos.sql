
-- --------------------------------------------------------

--
-- Estructura de la taula `tipos`
--

CREATE TABLE `tipos` (
  `idTipos` int(11) NOT NULL,
  `NombreTipo` varchar(45) NOT NULL,
  `Web` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Bolcament de dades per a la taula `tipos`
--

INSERT INTO `tipos` (`idTipos`, `NombreTipo`, `Web`) VALUES
(1, 'Camisetas', NULL),
(2, 'Vestidos', NULL),
(3, 'Vaqueros', NULL),
(4, 'Chaquetas y Abrigos', NULL),
(5, 'Ropa de Deporte', NULL),
(6, 'Americanas', NULL),
(7, 'Zapatos', NULL),
(8, 'Armani Masculino', NULL),
(9, 'Armani Femenino', NULL),
(10, 'Bolsos', NULL);
