
-- --------------------------------------------------------

--
-- Estructura de la taula `inventario`
--

CREATE TABLE `inventario` (
  `idInventario` int(11) NOT NULL,
  `idTienda` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `idTipos` int(11) NOT NULL,
  `Stock` int(11) NOT NULL,
  `Talla` varchar(20) NOT NULL,
  `Genero` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Bolcament de dades per a la taula `inventario`
--

INSERT INTO `inventario` (`idInventario`, `idTienda`, `idProducto`, `idTipos`, `Stock`, `Talla`, `Genero`) VALUES
(1, 1, 1, 1, 20, 'S', 'Masculino'),
(2, 1, 1, 1, 20, 'M', 'Masculino'),
(3, 1, 1, 1, 20, 'L', 'Masculino'),
(4, 1, 1, 1, 20, 'XL', 'Masculino'),
(5, 1, 2, 8, 20, 'S', 'Masculino'),
(6, 1, 2, 8, 20, 'M', 'Masculino'),
(7, 1, 2, 8, 20, 'L', 'Masculino'),
(8, 1, 2, 8, 20, 'XL', 'Masculino'),
(9, 1, 3, 8, 20, '39', 'Masculino'),
(10, 1, 3, 8, 20, '40', 'Masculino'),
(11, 1, 3, 8, 20, '41', 'Masculino'),
(12, 1, 3, 8, 20, '42', 'Masculino'),
(13, 1, 3, 8, 20, '43', 'Masculino'),
(14, 1, 3, 8, 20, '44', 'Masculino'),
(15, 1, 3, 8, 20, '45', 'Masculino'),
(16, 1, 4, 8, 20, '39', 'Masculino'),
(17, 1, 4, 8, 20, '40', 'Masculino'),
(18, 1, 4, 8, 20, '41', 'Masculino'),
(19, 1, 4, 8, 20, '42', 'Masculino'),
(20, 1, 4, 8, 20, '43', 'Masculino'),
(21, 1, 4, 8, 20, '44', 'Masculino'),
(22, 1, 4, 8, 20, '45', 'Masculino'),
(23, 1, 5, 8, 20, 'S', 'Masculino'),
(24, 1, 5, 8, 20, 'M', 'Masculino'),
(25, 1, 5, 8, 20, 'L', 'Masculino'),
(26, 1, 5, 8, 20, 'XL', 'Masculino'),
(27, 1, 6, 8, 20, 'S', 'Masculino'),
(28, 1, 6, 8, 20, 'M', 'Masculino'),
(29, 1, 6, 8, 20, 'L', 'Masculino'),
(30, 1, 6, 8, 20, 'XL', 'Masculino'),
(31, 1, 7, 8, 20, 'Talla única', 'Masculino'),
(32, 1, 8, 9, 20, '39', 'Femenino'),
(33, 1, 8, 9, 20, '40', 'Femenino'),
(34, 1, 8, 9, 20, '41', 'Femenino'),
(35, 1, 8, 9, 20, '42', 'Femenino'),
(36, 1, 9, 9, 20, 'S', 'Femenino'),
(37, 1, 9, 9, 20, 'M', 'Femenino'),
(38, 1, 9, 9, 20, 'L', 'Femenino'),
(39, 1, 9, 9, 20, 'XL', 'Femenino'),
(40, 1, 10, 9, 20, 'Talla única', 'Femenino'),
(41, 1, 11, 9, 20, '39', 'Femenino'),
(42, 1, 11, 9, 20, '40', 'Femenino'),
(43, 1, 11, 9, 20, '41', 'Femenino'),
(44, 1, 11, 9, 20, '42', 'Femenino'),
(45, 1, 12, 9, 20, 'Talla única', 'Femenino'),
(46, 1, 13, 9, 20, 'Talla única', 'Femenino');
